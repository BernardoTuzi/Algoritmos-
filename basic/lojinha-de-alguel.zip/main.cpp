
#include <stdio.h>

int main()
{
   int dias; 
    float km, total; 
    
    printf("me diga a quatidade de dias e o km percorrido respectivamente!\n"); 
    scanf("%d %f", &dias, &km); 
    total = (90 * dias) + (km * 0.20); 
    printf("valor a pagar = %.2f", total);
    

    return 0;
}